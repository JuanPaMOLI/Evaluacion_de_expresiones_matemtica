using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace ClientTCP
{
    public partial class Form1 : Form
    {
        private const int Port = 5000; // Puerto del servidor
        private TcpClient client;      // Cliente TCP
        private NetworkStream stream; // Flujo para enviar y recibir datos

        // Lista para mantener el historial
        private List<(string Fecha, string Expresión, string Resultado)> history;

        public Form1()
        {
            InitializeComponent();
            ConfigureComboBox(); // Configurar opciones del ComboBox
            ConnectToServer();

            // Inicializar historial
            history = new List<(string Fecha, string Expresión, string Resultado)>();
            InitializeHistoryGrid();
        }

        private void InitializeHistoryGrid()
        {
            // Configurar columnas del DataGridView
            historyGrid.Columns.Add("Fecha", "Fecha");
            historyGrid.Columns.Add("Expresión", "Expresión");
            historyGrid.Columns.Add("Resultado", "Resultado");
        }

        private void AddToHistory(string expression, string result)
        {
            string date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            history.Add((date, expression, result));
            historyGrid.Rows.Add(date, expression, result);
        }

        private void ConfigureComboBox()
        {
            // Configura el ComboBox con las opciones predefinidas
            modeComboBox.Items.Clear();
            modeComboBox.Items.Add("1 - Modo Lógico");
            modeComboBox.Items.Add("2 - Modo Aritmético");
        }

        private void ConnectToServer()
        {
            try
            {
                client = new TcpClient("127.0.0.1", Port);
                stream = client.GetStream();
                AppendToOutput("Conectado al servidor.");
            }
            catch (Exception ex)
            {
                AppendToOutput($"Error al conectar: {ex.Message}");
            }
        }

        private void AppendToOutput(string message)
        {
            outputBox.AppendText($"{message}\n");
            outputBox.ScrollToCaret();
        }

        private void SendToServer(string message)
        {
            if (client == null || stream == null)
                throw new InvalidOperationException("No conectado al servidor.");

            byte[] data = Encoding.UTF8.GetBytes(message + "\n");
            stream.Write(data, 0, data.Length);
        }

        private string ReceiveFromServer()
        {
            if (client == null || stream == null)
                throw new InvalidOperationException("No conectado al servidor.");

            StringBuilder messageBuilder = new StringBuilder();
            byte[] buffer = new byte[1024];
            int bytesRead;

            do
            {
                bytesRead = stream.Read(buffer, 0, buffer.Length);
                messageBuilder.Append(Encoding.UTF8.GetString(buffer, 0, bytesRead));
            } while (!messageBuilder.ToString().Contains("\n"));

            return messageBuilder.ToString().Trim();
        }

        private void setModeButton_Click(object sender, EventArgs e)
        {
            if (modeComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, seleccione un modo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener el índice y enviar el comando al servidor
            string selectedMode = modeComboBox.SelectedIndex == 0 ? "1" : "2";

            try
            {
                SendToServer(selectedMode);
                string response = ReceiveFromServer();
                AppendToOutput($"Modo establecido: {response}");
            }
            catch (Exception ex)
            {
                AppendToOutput($"Error al enviar modo: {ex.Message}");
            }
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            string expression = expressionInput.Text.Trim();
            if (string.IsNullOrEmpty(expression))
            {
                MessageBox.Show("Por favor, ingrese una operación.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                SendToServer(expression);
                string response = ReceiveFromServer();
                AppendToOutput($"Entrada: {expression}\nRespuesta del servidor: {response}");
                AddToHistory(expression, response);
                expressionInput.Clear();
            }
            catch (Exception ex)
            {
                AppendToOutput($"Error al calcular: {ex.Message}");
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            try
            {
                if (stream != null) stream.Close();
                if (client != null) client.Close();
            }
            catch (Exception ex)
            {
                AppendToOutput($"Error al cerrar conexión: {ex.Message}");
            }
        }
    }
}
