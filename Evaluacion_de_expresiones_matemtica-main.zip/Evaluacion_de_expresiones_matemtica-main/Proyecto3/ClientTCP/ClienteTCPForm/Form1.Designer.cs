﻿namespace ClientTCP
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ComboBox modeComboBox;
        private System.Windows.Forms.Button setModeButton;
        private System.Windows.Forms.TextBox expressionInput;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.RichTextBox outputBox;
        private System.Windows.Forms.DataGridView historyGrid;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.modeComboBox = new System.Windows.Forms.ComboBox();
            this.setModeButton = new System.Windows.Forms.Button();
            this.expressionInput = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.outputBox = new System.Windows.Forms.RichTextBox();
            this.historyGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.historyGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // modeComboBox
            // 
            this.modeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.modeComboBox.FormattingEnabled = true;
            this.modeComboBox.Location = new System.Drawing.Point(20, 20);
            this.modeComboBox.Name = "modeComboBox";
            this.modeComboBox.Size = new System.Drawing.Size(300, 21);
            this.modeComboBox.TabIndex = 0;
            // 
            // setModeButton
            // 
            this.setModeButton.Location = new System.Drawing.Point(340, 20);
            this.setModeButton.Name = "setModeButton";
            this.setModeButton.Size = new System.Drawing.Size(100, 23);
            this.setModeButton.TabIndex = 1;
            this.setModeButton.Text = "Enviar Modo";
            this.setModeButton.UseVisualStyleBackColor = true;
            this.setModeButton.Click += new System.EventHandler(this.setModeButton_Click);
            // 
            // expressionInput
            // 
            this.expressionInput.Location = new System.Drawing.Point(20, 60);
            this.expressionInput.Name = "expressionInput";
            this.expressionInput.Size = new System.Drawing.Size(300, 20);
            this.expressionInput.TabIndex = 2;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(340, 60);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 23);
            this.calculateButton.TabIndex = 3;
            this.calculateButton.Text = "Calcular";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // outputBox
            // 
            this.outputBox.Location = new System.Drawing.Point(20, 100);
            this.outputBox.Name = "outputBox";
            this.outputBox.Size = new System.Drawing.Size(420, 100);
            this.outputBox.TabIndex = 4;
            this.outputBox.Text = "";
            // 
            // historyGrid
            // 
            this.historyGrid.AllowUserToAddRows = false;
            this.historyGrid.AllowUserToDeleteRows = false;
            this.historyGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.historyGrid.Location = new System.Drawing.Point(20, 220);
            this.historyGrid.Name = "historyGrid";
            this.historyGrid.ReadOnly = true;
            this.historyGrid.Size = new System.Drawing.Size(420, 200);
            this.historyGrid.TabIndex = 5;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(484, 450);
            this.Controls.Add(this.historyGrid);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.expressionInput);
            this.Controls.Add(this.setModeButton);
            this.Controls.Add(this.modeComboBox);
            this.Name = "Form1";
            this.Text = "Cliente TCP - Evaluador de Expresiones";
            ((System.ComponentModel.ISupportInitialize)(this.historyGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
