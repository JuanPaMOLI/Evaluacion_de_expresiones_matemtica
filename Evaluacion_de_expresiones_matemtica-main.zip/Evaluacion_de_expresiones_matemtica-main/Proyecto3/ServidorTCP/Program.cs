﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

class TcpServer
{
    private const int Port = 5000;
    private const string CsvFilePath = "registro_operaciones.csv";

    public static async Task StartServer()
    {
        TcpListener server = new TcpListener(IPAddress.Loopback, Port);

        try
        {
            // Inicializar el archivo CSV si no existe
            if (!File.Exists(CsvFilePath))
            {
                using (StreamWriter writer = new StreamWriter(CsvFilePath, false))
                {
                    writer.WriteLine("ClienteID,Expresión,Resultado,Fecha");
                }
            }

            server.Start();
            Console.WriteLine($"Servidor TCP iniciado en {IPAddress.Loopback}:{Port}");

            while (true)
            {
                Console.WriteLine("Esperando conexiones...");
                TcpClient client = await server.AcceptTcpClientAsync();
                Console.WriteLine("Cliente conectado!");

                _ = Task.Run(() => HandleClient(client));
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
        finally
        {
            server.Stop();
            Console.WriteLine("Servidor detenido.");
        }
    }

    private static async Task HandleClient(TcpClient client)
    {
        using (NetworkStream stream = client.GetStream())
        {
            string ClienteID = Guid.NewGuid().ToString();
            Console.WriteLine($"Cliente conectado: {ClienteID}");

            byte[] buffer = new byte[1024];
            string mode = "aritmético";

            try
            {
                while (true)
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break;

                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();
                    Console.WriteLine($"[{ClienteID}] Mensaje recibido: {message}");

                    if (message.Equals("salir", StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine("Cliente desconectado.");
                        break;
                    }

                    string response;

                    // Identificar comandos
                    if (message == "1")
                    {
                        mode = "lógico";
                        response = "Modo lógico configurado. Ejemplo: (1 | 1) -> (1 1 |)";
                    }
                    else if (message == "2")
                    {
                        mode = "aritmético";
                        response = "Modo aritmético configurado. Ejemplo: (10 + 10) -> (10 10 +)";
                    }
                    else
                    {
                        // Procesar expresión según el modo
                        try
                        {
                            bool isLogicalMode = mode == "lógico";
                            ExpressionTree tree = new ExpressionTree(isLogicalMode);
                            tree.BuildTree(message); // Construir el árbol
                            string resultado = tree.Evaluate().ToString(); // Evaluar la expresión
                            response = $"Resultado: {resultado}";

                            // Registrar la operación en el archivo CSV
                            RegisterOperation(ClienteID, message, resultado);
                        }
                        catch (Exception ex)
                        {
                            response = $"Error: {ex.Message}"; // Capturar errores
                        }
                    }

                    // Enviar respuesta al cliente
                    byte[] responseData = Encoding.UTF8.GetBytes(response + "\n");
                    await stream.WriteAsync(responseData, 0, responseData.Length);
                    Array.Clear(buffer, 0, buffer.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error manejando cliente: {ex.Message}");
            }
        }
    }

    private static void RegisterOperation(string clientId, string expression, string result)
    {
        try
        {
            string date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string record = $"{clientId},{expression},{result},{date}";

            // Agregar el registro al archivo CSV
            using (StreamWriter writer = new StreamWriter(CsvFilePath, true))
            {
                writer.WriteLine(record);
            }

            Console.WriteLine($"Operación registrada: {record}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error registrando operación: {ex.Message}");
        }
    }

    public static async Task Main(string[] args)
    {
        await StartServer();
    }
}
